"use strict";

function MyApp() {
  const [count, setCount] = React.useState(0);

  function handleClick() {
    setCount(count + 1);
  }

  return (
    <div>
      <h1>Counters that update together</h1>
      <MyButton count={count} onClick={handleClick} /> {/* Se pasan como parámetros al constructor */}
      <MyButton count={count} onClick={handleClick} />
    </div>
  );
}

function MyButton({ count, onClick }) { {/* Constructor de componente con parámetros */}
  return (
    <button onClick={onClick}>
      Clicked {count} times
    </button>
  );
}
const container = document.getElementById('root');
const root = ReactDOM.createRoot(container);
root.render(<MyApp />);


