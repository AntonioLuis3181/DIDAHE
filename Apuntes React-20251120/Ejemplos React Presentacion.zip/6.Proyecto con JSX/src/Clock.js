
function Clock(){
    const [hora, setHora] = React.useState(new Date().toLocaleTimeString());

    setInterval(function (){ setHora(new Date().toLocaleTimeString())} , 1000);

    return (
        <h2>La hora es: {hora}</h2>
    );

}
  
const container = document.getElementById('root');
const root = ReactDOM.createRoot(container);
root.render(<Clock />);

  