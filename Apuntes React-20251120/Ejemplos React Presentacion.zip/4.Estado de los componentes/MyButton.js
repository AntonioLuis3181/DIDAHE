"use strict";

function MyButton() {
  const [count, setCount] = React.useState(0);

  function handleClick() {
    setCount(count + 1);
  }

  return (
    <button onClick={handleClick}>
      Clicked {count} times
    </button>
  );
}

const container = document.getElementById('root');
const root = ReactDOM.createRoot(container);
root.render(<MyButton />);
// Renderizamos una segunda vez el componente 
const container2 = document.getElementById('otro-root');
const root2 = ReactDOM.createRoot(container2);
root2.render(<MyButton />);


