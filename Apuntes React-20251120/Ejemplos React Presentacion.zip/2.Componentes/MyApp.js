"use strict";

function MyButton() {
    return (
      <button>
        I'm a button
      </button>
    );
  }
  
 function MyApp() {

    return (
      
      <div>
        <h1>Welcome to my app</h1>
        <MyButton />
      </div>
    );
  }

  const container = document.getElementById('root');
  const root = ReactDOM.createRoot(container);
  root.render(<MyApp />);
