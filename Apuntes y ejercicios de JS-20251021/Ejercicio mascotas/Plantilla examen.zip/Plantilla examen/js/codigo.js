"use strict";

// datosIniciales();

// Se facilitan datos de prueba sobre el objeto oAlbergue que se debe crear para resolver el ejercicio
function datosIniciales(){
  oAlbergue.altaMascota(new Perro(1,7,25)); // enAlbergue=false al crear mascotas
  oAlbergue.altaMascota(new Perro(4,22,52)); 
  oAlbergue.altaMascota(new Perro(7,3,20)); 
  oAlbergue.altaMascota(new Gato(22,3,"Siamés")); 
  oAlbergue.altaMascota(new Gato(41,7,"Egipcio")); 
  oAlbergue.altaMascota(new Gato(11,7,"Callejero")); 

  oAlbergue.altaMovimiento(1,"Aitor Menta",955123123,"E", new Date(2021, 09, 22));
  oAlbergue.altaMovimiento(4,"Lola Mento",955123543,"E", new Date(2021, 09, 24));
  oAlbergue.altaMovimiento(22,"Lola Mento",955678123,"E", new Date(2021, 09, 26));
  oAlbergue.altaMovimiento(41,"Federico Ramos",955222222,"E", new Date(2021, 10, 24));
  oAlbergue.altaMovimiento(11,"Lola Mento",955123123,"S", new Date(2021, 11, 14));
  oAlbergue.altaMovimiento(22,"Juan José Maldonado",954323456,"S", new Date(2021, 10, 26));
  oAlbergue.altaMovimiento(41,"María Unfavor",955222222,"S", new Date(2021, 11, 24));
}
